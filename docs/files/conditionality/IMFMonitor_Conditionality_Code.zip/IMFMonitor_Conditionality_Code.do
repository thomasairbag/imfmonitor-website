* ==============================================================================
* ==============================================================================
* IMF Monitor: 	IMFMonitor_Conditionality_Code.do
*				Conditionality Dataset Preparation
* Version: 		March 2026
* ==============================================================================
* ==============================================================================
capture cd "IMFMonitor"
* ==============================================================================
* Data checking
* ==============================================================================
import excel "IMFMonitor_Conditionality_Raw.xlsx", sheet("Dataset") firstrow clear
* Tabs
tab CountryName, missing
tab CountryCode, missing
tab ArrangementDate, missing
tab ArrangementID, missing
tab ArrangementType, missing
tab ArrangementDuration, missing
tab ArrangementAmount, missing
tab ConditionYear, missing
tab ConditionMonth, missing
tab ConditionType, missing
tab ConditionPolicyArea, missing
tab ConditionNumberApplicable, missing
tab ConditionSourceDocument, missing
tab ConditionImplementationStatus, missing
tab ConditionWaiver, missing
tab ConditionWaiverSourceDocument, missing
tab AdditionalNotes, missing
* All PCs are standard
tab ConditionText if ConditionType=="PC"
* SCs cannot have values greater than 1 for numbers applicable
tab ConditionNumberApplicable ConditionType, missing
* Benchmarks cannot be waivered and SCs can only have one waiver
tab2 ConditionType ConditionWaiver, missing
* Verify number of waivers against waiver source documents
split ConditionWaiverSourceDocument, parse(,)
gen waivR = 1 if !missing(ConditionWaiverSourceDocument1)
replace waivR = waivR + 1 if !missing(ConditionWaiverSourceDocument2)
replace waivR = waivR + 1 if !missing(ConditionWaiverSourceDocument3)
tab ConditionWaiver waivR, missing
drop ConditionWaiverSourceDocument1-waivR
* ==============================================================================
* Data cleaning
* ==============================================================================
drop ConditionMonth ConditionText ConditionSourceDocument
rename CountryName cname
rename CountryCode ccode
rename ArrangementDate a_appr
rename ArrangementID a_ebm
rename ArrangementType a_type
rename ArrangementDuration a_dur
rename ArrangementAmount a_amou
rename ConditionYear c_year
rename ConditionType c_type
rename ConditionPolicyArea c_polar
rename ConditionNumberApplicable c_quant
rename AdditionalNotes c_notes
rename ConditionWaiver c_waiv
rename ConditionWaiverSourceDocument c_waiv_s
* Recode implementation status: rescheduled conditions
gen c_res=1 if ConditionImplementationStatus=="Rescheduled"
replace c_res=1 if ConditionImplementationStatus=="Rescheduled, Upgraded"
replace c_res=1 if ConditionImplementationStatus=="Withdrawn, Rescheduled"
* Recode implementation status: upgraded conditions
gen c_upg=1 if ConditionImplementationStatus=="Upgraded"
replace c_upg=1 if ConditionImplementationStatus=="Rescheduled, Upgraded"
* Recode implementation status: conditions included in replacement arrangement
gen c_rep=1 if ConditionImplementationStatus=="Withdrawn" & c_notes=="Included in replacement arrangement"
replace c_rep=1 if ConditionImplementationStatus=="Withdrawn, Rescheduled"
* Drop withdrawn conditions
drop if ConditionImplementationStatus=="Withdrawn" & c_notes==""
drop ConditionImplementationStatus
* Remove PCs for arithmetic transformations
replace c_quant=0 if c_type=="PC"
* Remove missing waiver values for arithmetic transformations
replace c_waiv=0 if missing(c_waiv)
* Count waivers on rescheduled, upgraded, and replacement conditions but not the conditions
replace c_quant=0 if c_res==1 | c_rep==1 | c_upg==1
* Restrict period to complete years
drop if c_year<1980 | c_year>2019
* ==============================================================================
* Create burden of adjustment, implementation-corrected, and waiver indicators
* ==============================================================================
preserve
* Convert unit of analysis to country-year
collapse (sum) c_quant c_waiv, by(cname ccode c_year c_type c_polar)
gen c_pat = c_polar + "_" + c_type
drop c_type c_polar
reshape wide @c_quant @c_waiv, i(cname ccode c_year) j(c_pat) string
rename *c_quant *
rename *c_waiv *_W
drop *_SB_W *_IB_W
* Fill gaps in the time-series
encode ccode, gen(cid)
order cid, after(ccode)
xtset cid c_year
tsfill, full
foreach var of varlist cname ccode {
	bysort cid (`var') `var': replace `var' = `var'[_N]
}
xtset cid c_year
* Create policy-types without conditions and transform missing values for arithmetic transformations
foreach var in DEB ENV EXT FIN FP INS LAB OTH POV PRI RTP SOE SP {
	capture gen `var'_IB=0
	replace `var'_IB=0 if missing(`var'_IB)
	capture gen `var'_QPC=0
	replace `var'_QPC=0 if missing(`var'_QPC)
	capture gen `var'_QPC_W=0
	replace `var'_QPC_W=0 if missing(`var'_QPC_W)
	capture gen `var'_PA=0
	replace `var'_PA=0 if missing(`var'_PA)
	capture gen `var'_PA_W=0
	replace `var'_PA_W=0 if missing(`var'_PA_W)
	capture gen `var'_SPC=0
	replace `var'_SPC=0 if missing(`var'_SPC)
	capture gen `var'_SPC_W=0
	replace `var'_SPC_W=0 if missing(`var'_SPC_W)
	capture gen `var'_SB=0
	replace `var'_SB=0 if missing(`var'_SB)
}
* Generate indicators
foreach var in DEB ENV EXT FIN FP INS LAB OTH POV PRI RTP SOE SP {
	gen BA1`var' = `var'_PA + `var'_QPC + `var'_SPC + `var'_IB + `var'_SB
	lab var BA1`var' "BA1 indicator - `var'"
	gen BA2`var' = `var'_PA + `var'_QPC + `var'_SPC
	lab var BA2`var' "BA2 indicator - `var'"
	gen BA3`var' = 2*(`var'_PA) + 2*(`var'_QPC) + 2*(`var'_SPC) + `var'_IB + `var'_SB
	lab var BA3`var' "BA3 indicator - `var'"
	gen SCs`var' = `var'_PA + `var'_SPC + `var'_SB
	lab var SCs`var' "Structural conditions - `var'"
	gen QCs`var' = `var'_QPC + `var'_IB
	lab var QCs`var' "Quantitative conditions - `var'"
}
foreach var in BA1 BA2 BA3 QCs SCs {
	gen `var'TOT = `var'DEB + `var'ENV + `var'EXT + `var'FIN + `var'FP + `var'INS + `var'LAB + `var'OTH + `var'POV + `var'PRI + `var'RTP + `var'SOE + `var'SP
	lab var `var'TOT "`var' - Total"
}
foreach var in PA QPC SPC IB SB {
	gen `var'sTOT = DEB_`var' + ENV_`var' + EXT_`var' + FIN_`var' + FP_`var' + INS_`var' + LAB_`var' + OTH_`var' + POV_`var' + PRI_`var' + RTP_`var' + SOE_`var' + SP_`var'
	lab var `var'sTOT "`var's - Total"
}
egen W1 = rowtotal(*_W)
lab var W1 "W1 - Total number of waivers"
gen W2 = (100*W1)/BA2TOT
lab var W2 "W2 - Normalized number of waivers"
replace W2 = 0 if missing(W2)
* Remove years we are not yet concerned with due to incomplete waiver data
replace W1 = . if c_year>2014
replace W2 = . if c_year>2014
* Drop standard conditions
drop OTH_PC OTH_PC_W
* Generate implementation-corrected indicators
foreach var in DEB ENV EXT FIN FP INS LAB OTH POV PRI RTP SOE SP {
	gen cBA`var' = `var'_PA + `var'_QPC + `var'_SPC - `var'_PA_W - `var'_QPC_W - `var'_SPC_W
	lab var cBA`var' "cBA indicator - `var'"
	gen cSCs`var' = `var'_PA + `var'_SPC - `var'_PA_W - `var'_SPC_W
	gen cQCs`var' = `var'_QPC - `var'_QPC_W
}
foreach var in cBA cSCs cQCs {
	gen `var'TOT = `var'DEB + `var'ENV + `var'EXT + `var'FIN + `var'FP + `var'INS + `var'LAB + `var'OTH + `var'POV + `var'PRI + `var'RTP + `var'SOE + `var'SP
	lab var `var'TOT "`var' - Total"
}
save "temp01.dta", replace
restore
* ==============================================================================
* Create additional waiver indicator
* ==============================================================================
preserve
* Restrict period to years with complete review data
drop if c_year<1980 | c_year>2014
* Prepare data for reshape
split c_waiv_s, parse(,)
drop c_waiv_s
gen cid= _n
reshape long c_waiv_s, i(ccode cid) string
replace c_waiv_s = trim(c_waiv_s)
duplicates drop ccode c_waiv_s if c_waiv_s!="", force
gen year = substr(c_waiv_s,5,2)
destring year, replace
drop if missing(year)
replace year = year + 1900 if year>50 & !missing(year)
replace year = year + 2000 if year<50 & !missing(year)
gen W3 = !missing(year)
collapse (sum) W3, by(cname ccode year)
encode ccode, gen(cid)
order cid, after(ccode)
xtset cid year
tsfill, full
foreach var of varlist cname ccode {
	bysort cid (`var') `var': replace `var' = `var'[_N]
}
lab var W3 "W3 - Total number of waiver events"
rename year c_year
drop if c_year<1980 | c_year>2014
save "temp02.dta", replace
restore
* ==============================================================================
* Create implementation-discounted burden of adjustment indicators
* ==============================================================================
preserve
import excel "IMFMonitor_Reviews.xlsx", sheet("Dataset") firstrow clear
ren CountryName cname
ren CountryCode ccode
ren ArrangementDate a_appr
ren ArrangementID a_ebm
ren ArrangementType a_type
ren ArrangementDuration a_dur
ren ArrangementAmount a_amou
ren ArrangementParallel a_par
ren ReviewNumber r_num
ren ReviewID r_ebm
ren ReviewDate r_ebmdate
ren ReviewSourceDocument r_s
ren ReviewNextDate r_nxtrev
ren ReviewEstimate r_nxtest
ren AdditionalNotes r_notes
* Data checking
list cname-r_nxtrev if r_ebmdate>=r_nxtrev
list cname-r_nxtrev if r_nxtrev[_n-1]>=r_nxtrev[_n] & !missing(r_nxtrev[_n-1]) & (cname[_n] == cname[_n-1])
list cname-r_nxtrev if r_ebmdate[_n-1]>=r_ebmdate[_n]  & (cname[_n] == cname[_n-1])
list cname-r_nxtrev if a_appr[_n-1]>a_appr[_n]  & (cname[_n] == cname[_n-1])
* Data cleaning
drop r_nxtest r_notes
foreach var of varlist a_appr r_nxtrev r_ebmdate {
	format `var' %tddd/Mon/CCYY
}
egen cid = group(cname)
egen a_prog = group(cname a_appr)
bysort cname (a_appr r_ebmdate): gen r_event = _n
order cid a_prog r_event, after(ccode)
xtset cid r_event
gen r_nxtreva = f.r_ebmdate
format r_nxtreva %tddd/Mon/CCYY
gen r_days = r_nxtreva-r_nxtrev
lab var r_ebmdate "Review date"
lab var r_nxtrev "Next scheduled review date"
lab var r_nxtreva "Next actual review date"
lab var r_days "Days between scheduled and actual review date"
* Code interruptions
bysort a_prog (r_event): gen intperm = (!missing(r_nxtrev) & a_prog[_n+1]!=a_prog[_n] & r_days>90 & (a_type=="SBA" | a_type=="SBA, CCFF" | a_type=="SBA, CCFF, CCFF" | a_type=="SBA, CCFF, TFL" | a_type=="SBA, STF" | a_type=="SBA, TFL" | a_type=="SBA, ESF")) | (!missing(r_nxtrev) & a_prog[_n+1]!=a_prog[_n] & r_days>180 & (a_type=="EFF" | a_type=="EFF, BSFF" | a_type=="EFF, CCFF" | a_type=="EFF, CCFF, CCFF" | a_type=="EFF, CCFF, FCT" | a_type=="EFF, ESAF" | a_type=="EFF, FCT" | a_type=="EFF, FCT, CCFF" | a_type=="EFF, PRGF" | a_type=="EFF, SAF" | a_type=="EFF, TFL" | a_type=="ESAF" | a_type=="ESAF, CCFF" | a_type=="ESAF, EFF" | a_type=="ESAF, SBA" | a_type=="ESF" | a_type=="PRGF" | a_type=="PRGF, EFF" | a_type=="SAF" | a_type=="SAF, CCFF" | a_type=="SAF, ESAF" | a_type=="SBA, SAF" | a_type=="SBA, SAF, CCFF" | a_type=="ECF" | a_type=="ECF, EFF" | a_type=="PLL" | a_type=="SCF" | a_type=="SCF, SBA"))
bysort a_prog (r_event): gen inttemp = (!missing(r_nxtrev) & a_prog[_n+1]==a_prog[_n] & r_days>90 & (a_type=="SBA" | a_type=="SBA, CCFF" | a_type=="SBA, CCFF, CCFF" | a_type=="SBA, CCFF, TFL" | a_type=="SBA, STF" | a_type=="SBA, TFL" | a_type=="SBA, ESF")) | (!missing(r_nxtrev) & a_prog[_n+1]==a_prog[_n] & r_days>180 & (a_type=="EFF" | a_type=="EFF, BSFF" | a_type=="EFF, CCFF" | a_type=="EFF, CCFF, CCFF" | a_type=="EFF, CCFF, FCT" | a_type=="EFF, ESAF" | a_type=="EFF, FCT" | a_type=="EFF, FCT, CCFF" | a_type=="EFF, PRGF" | a_type=="EFF, SAF" | a_type=="EFF, TFL" | a_type=="ESAF" | a_type=="ESAF, CCFF" | a_type=="ESAF, EFF" | a_type=="ESAF, SBA" | a_type=="ESF" | a_type=="PRGF" | a_type=="PRGF, EFF" | a_type=="SAF" | a_type=="SAF, CCFF" | a_type=="SAF, ESAF" | a_type=="SBA, SAF" | a_type=="SBA, SAF, CCFF" | a_type=="ECF" | a_type=="ECF, EFF" | a_type=="PLL" | a_type=="SCF" | a_type=="SCF, SBA"))
* Manually code interruptions for some parallel agreements (where a_par==1 or a_par==4)
replace intperm=1 if ccode=="COD" & a_ebm=="EBM/87/74" & r_num==1
replace intperm=1 if ccode=="MRT" & a_ebm=="EBM/86/161" & r_num==1
replace intperm=1 if ccode=="TZA" & a_ebm=="EBM/86/140" & r_num==2
* Assign discounts per year
forvalues i=1980/2014 {
	gen dis`i' = .
	bysort a_prog (r_event): replace dis`i'= 4 if intperm==1 & `i'>year(r_nxtrev)
	bysort a_prog (r_event): replace dis`i'= 5 - quarter(r_nxtrev) if intperm==1 & `i'==year(r_nxtrev)
	bysort a_prog (r_event): replace dis`i'= quarter(r_nxtreva)-quarter(r_nxtrev) if inttemp==1 & `i'==year(r_nxtrev) & year(r_nxtrev)==year(r_nxtreva)
	bysort a_prog (r_event): replace dis`i'= 5 - quarter(r_nxtrev) if inttemp==1 & `i'==year(r_nxtrev) & year(r_nxtrev)<year(r_nxtreva)
	bysort a_prog (r_event): replace dis`i'= 4 if inttemp==1 & `i'>year(r_nxtrev) & `i'<year(r_nxtreva)
	bysort a_prog (r_event): replace dis`i'= quarter(r_nxtreva)-1 if inttemp==1 & `i'==year(r_nxtreva) & year(r_nxtrev)<year(r_nxtreva)
}
reshape long dis, i(cname ccode cid a_prog r_event a_appr a_ebm a_dur a_amou) j(year)
collapse (sum) dis, by(cname ccode cid a_prog a_appr a_ebm a_type a_dur a_amou year) 
recode dis (0=1) (1=0.75) (2=0.5) (3=0.25) (4=0), gen(discoef)
rename year c_year
save "temp03.dta", replace
restore
preserve
* Restrict period to years with complete review data
drop if c_year<1980 | c_year>2014
* Drop standard PCs as not relevant for discounts
drop if c_type=="PC"
* Convert unit of analysis to country-program-year to apply discounts
collapse (sum) c_quant, by(cname ccode a_ebm a_type c_year c_type c_polar)
gen c_pat = c_polar + "_" + c_type
drop c_type c_polar
reshape wide @c_quant, i(cname ccode a_ebm a_type c_year) j(c_pat) string
rename *c_quant *
* Create policy-types without conditions and transform missing values for arithmetic transformations
foreach var in DEB ENV EXT FIN FP INS LAB OTH POV PRI RTP SOE SP {
	capture gen `var'_IB=0
	replace `var'_IB=0 if missing(`var'_IB)
	capture gen `var'_QPC=0
	replace `var'_QPC=0 if missing(`var'_QPC)
	capture gen `var'_PA=0
	replace `var'_PA=0 if missing(`var'_PA)
	capture gen `var'_SPC=0
	replace `var'_SPC=0 if missing(`var'_SPC)
	capture gen `var'_SB=0
	replace `var'_SB=0 if missing(`var'_SB)
}
merge 1:1 cname a_ebm c_year using "temp03.dta", keepusing(discoef)
drop if _merge==2 
* Check master c_years are matched except for programs that do not require reviews
list cname ccode a_type c_year if _merge==1
drop _merge
* Clean merge
replace discoef=1 if missing(discoef)
* Apply discounts to burden of adjustment indicators
foreach var of varlist DEB* ENV* EXT* FIN* FP* INS* LAB* OTH* POV* PRI* RTP* SOE* SP* {
	replace `var'=`var'*discoef
} 
* Convert unit of analysis to country-year
collapse (sum) DEB* ENV* EXT* FIN* FP* INS* LAB* OTH* POV* PRI* RTP* SOE* SP*, by(cname ccode c_year)
* Fill gaps in the time-series
encode ccode, gen(cid)
order cid, after(ccode)
xtset cid c_year
tsfill, full
foreach var of varlist cname ccode {
	bysort cid (`var') `var': replace `var' = `var'[_N]
}
xtset cid c_year
* Transform missing values for arithmetic transformations below
foreach var of varlist DEB* ENV* EXT* FIN* FP* INS* LAB* OTH* POV* PRI* RTP* SOE* SP* {
	replace `var'=0 if missing(`var') 
}  
* Generate indicators
foreach var in DEB ENV EXT FIN FP INS LAB OTH POV PRI RTP SOE SP {
	gen dBA1`var' = `var'_PA + `var'_QPC + `var'_SPC + `var'_IB + `var'_SB
	lab var dBA1`var' "dBA1 indicator - `var'"
	gen dBA2`var' = `var'_PA + `var'_QPC + `var'_SPC
	lab var dBA2`var' "dBA2 indicator - `var'"
	gen dBA3`var' = 2*(`var'_PA) + 2*(`var'_QPC) + 2*(`var'_SPC) + `var'_IB + `var'_SB
	lab var dBA3`var' "dBA3 indicator - `var'"
	gen dSCs`var' = `var'_PA + `var'_SPC + `var'_SB
	gen dQCs`var' = `var'_QPC + `var'_IB
}
foreach var in dBA1 dBA2 dBA3 dSCs dQCs {
	gen `var'TOT = `var'DEB + `var'ENV + `var'EXT + `var'FIN + `var'FP + `var'INS + `var'LAB + `var'OTH + `var'POV + `var'PRI + `var'RTP + `var'SOE + `var'SP
	lab var `var'TOT "`var' - Total"
}
foreach var in PA QPC SPC IB SB {
	gen d`var'sTOT = DEB_`var' + ENV_`var' + EXT_`var' + FIN_`var' + FP_`var' + INS_`var' + LAB_`var' + OTH_`var' + POV_`var' + PRI_`var' + RTP_`var' + SOE_`var' + SP_`var'
	lab var d`var'sTOT "d`var's - Total"
}
save "temp04.dta", replace
restore
* ==============================================================================
* Create program participation indicators
* ==============================================================================
import excel "IMFMonitor_Programs.xlsx", sheet("Dataset") firstrow clear
* Data checking tabs
tab CountryName, missing
tab CountryCode, missing
tab ArrangementDate, missing
tab ArrangementType, missing
tab ArrangementExpirationDate, missing
* Check facilities without durations
tab ArrangementType ArrangementDuration, missing
drop if ArrangementDuration=="."
* Drop unneeded variables
drop ArrangementAmount ArrangementDuration ArrangementSourceDocument Augmentation* AdditionalNotes
* Generate formatted start and end dates
format ArrangementDate %tddd/Mon/CCYY
gen End = date(ArrangementExpirationDate, "MDY")
drop if missing(End)
format End %tddd/Mon/CCYY
gen months = mofd(End) - mofd(ArrangementDate)
drop ArrangementExpirationDate
* Sort dataset for cleaning
sort CountryName ArrangementDate months
rename CountryName Country
rename ArrangementType Facility
rename ArrangementDate Date
preserve
* ALL PROGRAMS
* Drop country-programs with identical start and end dates
list Country Facility Date End months if Country[_n+1]==Country[_n] & Date[_n+1]==Date[_n] & End[_n+1]==End[_n]
drop if Country[_n+1]==Country[_n] & Date[_n+1]==Date[_n] & End[_n+1]==End[_n]
* Drop country-program with less months for identical start dates and different end dates
list Country Facility Date End months if Country[_n+1]==Country[_n] & Date[_n+1]==Date[_n]
drop if Country[_n+1]==Country[_n] & Date[_n+1]==Date[_n]
* Drop country-program with later start date for identical end dates and different start dates
list Country Facility Date End months if (Country[_n-1]==Country[_n] & End[_n]<=End[_n-1])
drop if (Country[_n-1]==Country[_n] & End[_n]<=End[_n-1])
* Set overlapping country-programs to latest end date to capture spell then drop country-program with start date earlier than previous program end date
list Country Facility Date End months if (Country[_n+1]==Country[_n] & Date[_n+1]<End[_n])
replace End=End[_n+1] if Country[_n+1]==Country[_n] & Date[_n+1]<End[_n] & End[_n+1]>End[_n]
drop if Country[_n-1]==Country[_n] & Date[_n]<End[_n-1]
foreach year of numlist 1980/2019 {
	gen IMFm`year' = .
	replace IMFm`year' = month(End) - month(Date) if `year'==year(Date) & year(End) == year(Date)
	replace IMFm`year' = 13 - month(Date) if `year'==year(Date) & year(End)!=year(Date)
	replace IMFm`year' = month(End) if `year'==year(End) & year(End)!=year(Date)
	replace IMFm`year' = 12 if `year'<year(End) & `year'>year(Date)
	gen IMFnn`year' = `year'>=year(Date) & `year'<=year(End)
	gen IMF6n`year' = `year'==year(End)
}
collapse (sum) IMFm* (max) IMFnn* (max) IMF6n*, by(Country) 
foreach year of numlist 1980/2019 {
	gen IMF33`year' = IMFm`year'>=3
	gen IMF44`year' = IMFm`year'>=4
	gen IMF55`year' = IMFm`year'>=5
	gen IMF66`year' = IMFm`year'>=6
	replace IMF6n`year' = 1 if IMFm`year'>=6
}
reshape long IMFm IMFnn IMF6n IMF33 IMF44 IMF55 IMF66, i(Country) j(year)
replace IMFm = 12 if IMFm==13
rename Country cname
save "temp05.dta", replace
restore
* CONCESSIONAL PROGRAMS
preserve
keep if Facility=="ECF" | Facility=="ESAF" | Facility=="ESF" | Facility=="PRGF" | Facility=="SAF" | Facility=="SCF"
* Drop country-programs with identical start and end dates
list Country Facility Date End months if Country[_n+1]==Country[_n] & Date[_n+1]==Date[_n] & End[_n+1]==End[_n]
drop if Country[_n+1]==Country[_n] & Date[_n+1]==Date[_n] & End[_n+1]==End[_n]
* Drop country-program with less months for identical start dates and different end dates
list Country Facility Date End months if Country[_n+1]==Country[_n] & Date[_n+1]==Date[_n]
drop if Country[_n+1]==Country[_n] & Date[_n+1]==Date[_n]
* Drop country-program with later start date for identical end dates and different start dates
list Country Facility Date End months if (Country[_n-1]==Country[_n] & End[_n]<=End[_n-1])
drop if (Country[_n-1]==Country[_n] & End[_n]<=End[_n-1])
* Set overlapping country-programs to latest end date to capture spell then drop country-program with start date earlier than previous program end date
list Country Facility Date End months if (Country[_n+1]==Country[_n] & Date[_n+1]<End[_n])
replace End=End[_n+1] if Country[_n+1]==Country[_n] & Date[_n+1]<End[_n] & End[_n+1]>End[_n]
drop if Country[_n-1]==Country[_n] & Date[_n]<End[_n-1]
foreach year of numlist 1980/2019 {
	gen conIMFm`year' = .
	replace conIMFm`year' = month(End) - month(Date) if `year'==year(Date) & year(End) == year(Date)
	replace conIMFm`year' = 13 - month(Date) if `year'==year(Date) & year(End)!=year(Date)
	replace conIMFm`year' = month(End) if `year'==year(End) & year(End)!=year(Date)
	replace conIMFm`year' = 12 if `year'<year(End) & `year'>year(Date)
	gen conIMFnn`year' = `year'>=year(Date) & `year'<=year(End)
	gen conIMF6n`year' = `year'==year(End)
}
collapse (sum) conIMFm* (max) conIMFnn* (max) conIMF6n*, by(Country) 
foreach year of numlist 1980/2019 {
	gen conIMF33`year' = conIMFm`year'>=3
	gen conIMF44`year' = conIMFm`year'>=4
	gen conIMF55`year' = conIMFm`year'>=5
	gen conIMF66`year' = conIMFm`year'>=6
	replace conIMF6n`year' = 1 if conIMFm`year'>=6
}
reshape long conIMFm conIMFnn conIMF6n conIMF33 conIMF44 conIMF55 conIMF66, i(Country) j(year)
replace conIMFm = 12 if conIMFm==13
rename Country cname
save "temp06.dta", replace
restore
* NON-CONCESSIONAL PROGRAMS
preserve
drop if Facility=="ECF" | Facility=="ESAF" | Facility=="ESF" | Facility=="PRGF" | Facility=="SAF" | Facility=="SCF"
* Drop country-programs with identical start and end dates
list Country Facility Date End months if Country[_n+1]==Country[_n] & Date[_n+1]==Date[_n] & End[_n+1]==End[_n]
drop if Country[_n+1]==Country[_n] & Date[_n+1]==Date[_n] & End[_n+1]==End[_n]
* Drop country-program with less months for identical start dates and different end dates
list Country Facility Date End months if Country[_n+1]==Country[_n] & Date[_n+1]==Date[_n]
drop if Country[_n+1]==Country[_n] & Date[_n+1]==Date[_n]
* Drop country-program with later start date for identical end dates and different start dates
list Country Facility Date End months if (Country[_n-1]==Country[_n] & End[_n]<=End[_n-1])
drop if (Country[_n-1]==Country[_n] & End[_n]<=End[_n-1])
* Set overlapping country-programs to latest end date to capture spell then drop country-program with start date earlier than previous program end date
list Country Facility Date End months if (Country[_n+1]==Country[_n] & Date[_n+1]<End[_n])
replace End=End[_n+1] if Country[_n+1]==Country[_n] & Date[_n+1]<End[_n] & End[_n+1]>End[_n]
drop if Country[_n-1]==Country[_n] & Date[_n]<End[_n-1]
foreach year of numlist 1980/2019 {
	gen nonIMFm`year' = .
	replace nonIMFm`year' = month(End) - month(Date) if `year'==year(Date) & year(End) == year(Date)
	replace nonIMFm`year' = 13 - month(Date) if `year'==year(Date) & year(End)!=year(Date)
	replace nonIMFm`year' = month(End) if `year'==year(End) & year(End)!=year(Date)
	replace nonIMFm`year' = 12 if `year'<year(End) & `year'>year(Date)
	gen nonIMFnn`year' = `year'>=year(Date) & `year'<=year(End)
	gen nonIMF6n`year' = `year'==year(End)
}
collapse (sum) nonIMFm* (max) nonIMFnn* (max) nonIMF6n*, by(Country) 
foreach year of numlist 1980/2019 {
	gen nonIMF33`year' = nonIMFm`year'>=3
	gen nonIMF44`year' = nonIMFm`year'>=4
	gen nonIMF55`year' = nonIMFm`year'>=5
	gen nonIMF66`year' = nonIMFm`year'>=6
	replace nonIMF6n`year' = 1 if nonIMFm`year'>=6
}
reshape long nonIMFm nonIMFnn nonIMF6n nonIMF33 nonIMF44 nonIMF55 nonIMF66, i(Country) j(year)
replace nonIMFm = 12 if nonIMFm==13
rename Country cname
save "temp07.dta", replace
restore
* ==============================================================================
* Create main dataset
* ==============================================================================
import excel "Merge\WBINCOME_static.xls", sheet("Worked") cellrange(A1:B219) firstrow clear
rename Economy cname
rename Code ccode
lab var cname "Country Name"
lab var ccode "Country Code World Bank"
gen year = .
format year %ty
lab var year Year
expand 40
sort cname
encode cname, gen(cid)
xtset cid
local i=1
foreach X of numlist 1980/2019 {
	bysort cname: replace year = `X' if _n==`i'
	local i=`i'+1
}
drop cid
replace cname="Cote d'Ivoire" if cname=="Côte d'Ivoire"
replace cname="Curacao" if cname=="Curaçao"
replace cname="Sao Tome and Principe" if cname=="São Tomé and Principe"
compress
sort cname year
rename year c_year
* MERGE DATASETS
merge 1:1 ccode c_year using temp01.dta
drop _merge cid
drop c*DEB c*ENV c*EXT c*FIN c*FP c*INS c*LAB c*OTH c*POV c*PRI c*RTP c*SOE c*SP
encode ccode, gen(cid)
order cid, after(ccode)
merge 1:1 ccode c_year using temp02.dta, keepusing(W3)
drop _merge
merge 1:1 ccode c_year using temp04.dta, keepusing(dBA* dQCsTOT dSCsTOT dQPCsTOT dIBsTOT dPAsTOT dSPCsTOT dSBsTOT)
drop _merge
rename c_year year
merge 1:1 cname year using temp05.dta, gen(_mer1)
merge 1:1 cname year using temp06.dta, gen(_mer2)
merge 1:1 cname year using temp07.dta, gen(_mer3)
drop _mer*
* ORDER DATA
order QPCsTOT IBsTOT PAsTOT SPCsTOT SBsTOT, after(OTH_QPC_W)
order BA1*, after(SBsTOT)
order BA2*, after(BA1TOT)
order BA3*, after(BA2TOT)
order QCs*, after(BA3TOT)
order SCs*, after(QCsTOT)
order cBA*, after(SCsTOT)
order cQCsTOT, after(cBATOT)
order cSCsTOT, after(cQCsTOT)
order dBA1*, after(cSCsTOT)
order dBA2*, after(dBA1TOT)
order dBA3*, after(dBA2TOT)
order dQCsTOT, after(dBA3TOT)
order dSCsTOT, after(dQCsTOT)
order dQPCsTOT dIBsTOT dPAsTOT dSPCsTOT dSBsTOT, after(dSCsTOT)
order ENV_IB, before(ENV_PA)
order ENV_QPC ENV_QPC_W, before(ENV_SB)
order INS_IB, before(INS_PA)
order INS_QPC INS_QPC_W, before(INS_SB)
order OTH_IB, before(OTH_PA)
order OTH_QPC OTH_QPC_W, before(OTH_SB)
* Replace missing values with zero except where country is unformed or defunct
foreach var of varlist DEB_IB-nonIMF66 {
	replace `var'=0 if missing(`var')
	replace `var'=. if (cname=="Estonia" | cname=="Latvia" | cname=="Lithuania" | cname=="Kazakhstan" | cname=="Kyrgyz Republic" | cname=="Tajikistan" | cname=="Turkmenistan" | cname=="Uzbekistan" | cname=="Belarus" | cname=="Moldova" | cname=="Ukraine" | cname=="Russian Federation" | cname=="Armenia" | cname=="Azerbaijan" | cname=="Georgia") & year<1992
	replace `var'=. if (cname=="Croatia" & year<1991) | (cname=="Slovenia" & year<1991) | (cname=="Bosnia and Herzegovina" & year<1992) | (cname=="North Macedonia" & year<1993) | (cname=="Montenegro" & year<2006) | (cname=="Kosovo" & year<2008) | (cname=="Serbia" & year<1992)
	replace `var'=. if cname=="Yugoslavia" & year>1991
	replace `var'=. if (cname=="Czech Republic" | cname=="Slovak Republic") & year<1993
	replace `var'=. if cname=="Czechoslovakia" & year>1992
	replace `var'=. if cname=="Timor-Leste" & year<2002
	replace `var'=. if cname=="Namibia" & year<1990
	replace `var'=. if cname=="Eritrea" & year<1993
	replace `var'=. if cname=="Yemen, Rep." & year<1990
	replace `var'=. if cname=="South Sudan" & year<2011
	replace `var'=. if cname=="Palau" & year<1994
}
* Recode as missing indicators that are not measured beyond 2014
foreach var of varlist cBA* cSCsTOT cQCsTOT dBA* dQCsTOT dSCsTOT dQPCsTOT dIBsTOT dPAsTOT dSPCsTOT dSBsTOT W1 W2 W3  *_W {
	replace `var'=. if year>2014
}
compress
sort cname year
drop cid
* Label variables
foreach var of varlist DEB_* {
	lab var `var' "External debt [DEB]"
}
foreach var of varlist ENV_* {
	lab var `var' "Land & environment [ENV]"
}
foreach var of varlist EXT_* {
	lab var `var' "External sector (trade & exchange) [EXT]"
}
foreach var of varlist FIN_* {
	lab var `var' "Financial, monetary & Central Bank [FIN]"
}
foreach var of varlist FP_* {
	lab var `var' "Fiscal [FP]"
}
foreach var of varlist INS_* {
	lab var `var' "Institutional [INS]"
}
foreach var of varlist LAB_* {
	lab var `var' "Labor (public & private sector) [LAB]"
}
foreach var of varlist OTH_* {
	lab var `var' "Residual [RES]"
}
foreach var of varlist POV_* {
	lab var `var' "Anti-poverty [POV]"
}
foreach var of varlist PRI_* {
	lab var `var' "Privatization [PRI]"
}
foreach var of varlist RTP_* {
	lab var `var' "Revenues & tax [RTP]"
}
foreach var of varlist SOE_* {
	lab var `var' "SOE reform & pricing [SOE]"
}
foreach var of varlist SP_* {
	lab var `var' "Social policy [SP]"
}
foreach var of varlist *_IB* {
	local lbl: variable label `var'
	lab var `var' "`lbl' indicative benchmarks"
}
foreach var of varlist *_PA* {
	local lbl: variable label `var'
	lab var `var' "`lbl' prior actions"
}
foreach var of varlist *_QPC* {
	local lbl: variable label `var'
	lab var `var' "`lbl' quantitative performance criteria"
}
foreach var of varlist *_SB* {
	local lbl: variable label `var'
	lab var `var' "`lbl' structural benchmarks"
}
foreach var of varlist *_SPC* {
	local lbl: variable label `var'
	lab var `var' "`lbl' structural performance criteria"
}
foreach var of varlist *_W {
	local lbl: variable label `var'
	lab var `var' "`lbl' waivers"
}
foreach var of varlist non* {
	lab var `var' "Non-concessional "
}
foreach var of varlist con* {
	lab var `var' "Concessional "
}
foreach var of varlist *IMF* {
	local lbl: variable label `var'
	lab var `var' "`lbl'IMF program active"
}
foreach var of varlist *m {
	local lbl: variable label `var'
	lab var `var' "`lbl' in number of months"
}
foreach var of varlist *nn {
	local lbl: variable label `var'
	lab var `var' "`lbl' anytime in year"
}
foreach var of varlist *6n {
	local lbl: variable label `var'
	lab var `var' "`lbl' for 6+ months in 1st year or anytime in last year"
}
foreach var of varlist *33 {
	local lbl: variable label `var'
	lab var `var' "`lbl' for 3+ months"
}
foreach var of varlist *44 {
	local lbl: variable label `var'
	lab var `var' "`lbl' for 4+ months"
}
foreach var of varlist *55 {
	local lbl: variable label `var'
	lab var `var' "`lbl' for 5+ months"
}
foreach var of varlist *66 {
	local lbl: variable label `var'
	lab var `var' "`lbl' for 6+ months"
}
notes: IMF Conditionality Main Dataset, 1980-2019. 
notes: When using the data, cite: Kentikelenis, A. & Stubbs, T. (2023). A Thousand Cuts: Social Protection in the Age of Austerity. Oxford University Press. 
notes: The codebook is available at: https://www.imfmonitor.org/conditionality
notes: For comments and suggestions, email thomas.stubbs@rhul.ac.uk
save "IMFMonitor_Conditionality_Main.dta", replace
erase temp01.dta
erase temp02.dta
erase temp03.dta
erase temp04.dta
erase temp05.dta
erase temp06.dta
erase temp07.dta
